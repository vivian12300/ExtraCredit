import Cocoa

var greeting = "Hello, playground"

//variables
var intro = "The ants go marching "
var hurrah = ", hurrah, hurrah"
var little = "The little one stops to "
var ground = "And they all go marching down to the ground, to get out, of the rain"

var num = 1

//loop
while num <= 10{
    print(intro + String(num) + " by " + String(num) + hurrah)
    print(intro + String(num) + " by " + String(num) + hurrah)
    print(intro + String(num) + " by " + String(num))
    print(little + " suck his thumb")
    print(ground)
num = num + 1
}

//not sure how to make the phrase change every time

/* while num == 2{
    print(little + " tie her shoe")
    print(ground) ? */
